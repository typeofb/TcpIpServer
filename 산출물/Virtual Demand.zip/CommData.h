//---------------------------------------------------------------------------
#ifndef CommDataH
#define CommDataH
//---------------------------------------------------------------------------
#include "Comm.h"
#define   LOAD_NUMBER   (int)32

typedef struct CommDataInterface {

// DC Data Dump
  int   UserId;
  long  EstimatePower;
  long  TargetPower;
  long  PresentPower;
  long  BasePower;
  word  DemandTime;
  byte  AlarmFlag;
  byte  ControlModeFlag;
  byte  DLCCommStatus;
  word  RCUCommStatus;
  long  RCULoadStatus;
  byte  DCLoad1;
  byte  DCLoad2;  
  word  DCYear;
  word  DCMonth;
  word  DCDay;
  word  DCHour;
  word  DCMinute;
  word  DCSec;

  word  RCUNumber;
  word  RCUNo[LOAD_NUMBER];

  long  RCUCurrentA[LOAD_NUMBER];
  long  RCUCurrentB[LOAD_NUMBER];
  long  RCUCurrentC[LOAD_NUMBER];

  long  RCUVoltageA[LOAD_NUMBER];
  long  RCUVoltageB[LOAD_NUMBER];
  long  RCUVoltageC[LOAD_NUMBER];

  long  RCUActivePowerA[LOAD_NUMBER];
  long  RCUActivePowerB[LOAD_NUMBER];
  long  RCUActivePowerC[LOAD_NUMBER];

  long  RCUReactivePowerA[LOAD_NUMBER];
  long  RCUReactivePowerB[LOAD_NUMBER];
  long  RCUReactivePowerC[LOAD_NUMBER];

  long  RCUVAPowerA[LOAD_NUMBER];
  long  RCUVAPowerB[LOAD_NUMBER];
  long  RCUVAPowerC[LOAD_NUMBER];

  word  RCUPowerFactorA[LOAD_NUMBER];
  word  RCUPowerFactorB[LOAD_NUMBER];
  word  RCUPowerFactorC[LOAD_NUMBER];

  word  RCUFrequency[LOAD_NUMBER];
  long  RCUDemandPower[LOAD_NUMBER];

// DC Setting Read
  word  SetID;
  long  SetTargetPower;
  word  SetPulse;
  long  SetCPTRatio;
  byte  SetServerCommInterval;
  byte  SetLoadControlMode;
  byte  SetControlOnTime;
  byte  SetControlOffTime;
  word  SetRCUTimeOut;
  byte  SetRCURetryNum;
  byte  SetDualPulseFlag;
  byte  SetDirectLoad1Enabled;
  byte  SetDirectLoad2Enabled;
  byte  SetControlMethod;
  byte  SetLoadControlStartTime;
  byte  SetAlarmEnabled;

// DC Setting Write
  word  WSetID;
  long  WSetTargetPower;
  word  WSetPulse;
  long  WSetCPTRatio;
  byte  WSetServerCommInterval;
  byte  WSetLoadControlMode;
  byte  WSetControlOnTime;
  byte  WSetControlOffTime;
  word  WSetRCUTimeOut;
  byte  WSetRCURetryNum;
  byte  WSetDualPulseFlag;
  byte  WSetDirectLoad1Enabled;
  byte  WSetDirectLoad2Enabled;
  byte  WSetControlMethod;
  byte  WSetLoadControlStartTime;
  byte  WSetAlarmEnabled;

// DLC Setting
  byte  SetTCPConnectMode;
  byte  SetLocalIP1;
  byte  SetLocalIP2;
  byte  SetLocalIP3;
  byte  SetLocalIP4;
  byte  SetSubnetMask1;
  byte  SetSubnetMask2;
  byte  SetSubnetMask3;
  byte  SetSubnetMask4;
  byte  SetGateway1;
  byte  SetGateway2;
  byte  SetGateway3;
  byte  SetGateway4;
  word  SetLocalPort;
  byte  SetServerIP1;
  byte  SetServerIP2;
  byte  SetServerIP3;
  byte  SetServerIP4;
  word  SetServerPort;
  byte  SetTimeOut;
  byte  SetMuxType;
  word  SetWaterMark;
  char  SetADSLUserID[15];
  char  SetADSLUserPassWd[8];

// DC REPORT
  word  TxRcuNo;
  word  TxReportYear;
  word  TxReportMonth;
  word  TxReportDay;

  word  RxRcuNo;
  word  RxReportYear;
  word  RxReportMonth;
  word  RxReportDay;
  
}CommDataInterface;
//---------------------------------------------------------------------------
extern CommDataInterface CommData;

void DCDataDump();
void DCSettingData();
void DLCSettingData();
#endif



