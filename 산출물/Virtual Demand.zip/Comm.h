//---------------------------------------------------------------------------
#ifndef CommH
#define CommH
//---------------------------------------------------------------------------
#define     BUFFSIZE        (unsigned short)30000
#define     BUFFHALFSIZE    (unsigned short)(BUFFSIZE/2)

#define     STX					    0x02 	/*   Indicate start of text   */
#define     ETX					    0x03 	/*   Indicate	end of text   */
#define 	  DLE					    0x10
#define     START_SANION    0x7E

#define     LED_ON          1
#define     LED_OFF         0

#define     CMD_BCC_CONNECT               ((char ) 'C')
#define     CMD_BCC_MONITOR               ((char ) 'V')
#define     CMD_BCC_QUIT                  ((char ) 'Q')
#define     CMD_BCC_TEXT                  ((char ) 'T')
#define     CMD_BCC_TEXT_SERVER           ((char ) 't')
#define     CMD_BCC_ALARM_CONFIRM         ((char ) 'A')
#define     CMD_BCC_CONTROL_RESULT          ((char ) 'a')
#define     CMD_BCC_AUTO                  ((char ) 'X')
#define     CMD_BCC_MANUAL                ((char ) 'x')
#define     CMD_BCC_LOAD_CONTROL          ((char ) 'N')
#define     CMD_BCC_CONTROL               ((char ) 'L')
#define     CMD_BCC_CONTROL_START         ((char ) 'b')
#define     CMD_BCC_TIME_SYNC             ((char ) 'T')  

#define     CMD_15_POWER              ((char ) 'Z')
#define     CMD_SETTING_READ              ((char ) 's')
#define     CMD_SETTING_WRITE             ((char ) 'S')
#define     CMD_MESSAGE                   ((char ) 'K')

#define     CMD_DAILY_REPORT              ((char ) 'H')
#define     CMD_DAILY_REPORT_RESULT_L8    ((char ) 'h')
#define     CMD_DAILY_REPORT_RESULT_L16   ((char ) 'H')

#define     CMD_MONTHLY_REPORT            ((char ) 'M')
#define     CMD_MONTHLY_REPORT_RESULT_L8  ((char ) 'm')
#define     CMD_MONTHLY_REPORT_RESULT_L16 ((char ) 'M')

#define     CMD_YEARLY_REPORT             ((char ) 'P')
#define     CMD_YEARLY_REPORT_RESULT_L8   ((char ) 'p')
#define     CMD_YEARLY_REPORT_RESULT_L16  ((char ) 'P')

#define     CMD_POWER_ON_OFF_REPORT       ((char ) 'R')
#define     CMD_POWER_ON_OFF_REPORT_L8    ((char ) 'r')
#define     CMD_POWER_ON_OFF_REPORT_L16   ((char ) 'R')


#define     CMD_EVENT_REPORT              ((char ) 'E')
#define     CMD_EVENT_REPORT_RESULT_L8    ((char ) 'e')
#define     CMD_EVENT_REPORT_RESULT_L16   ((char ) 'E')

#define     CMD_USER_COMM_DATA            ((char ) 'X')
#define     CMD_USER_COMM_RESET           ((char ) 'R')
#define     CMD_USER_COMM_FILE_DB         ((char ) 'F')
#define     CMD_USER_COMM_FILE_SETTING    ((char ) 'G')

#define     CMD_ACK_CONFIRM               ((char ) 'B')


#define     CMD_MESSAGE_HAESUL    0x08
#define     CMD_COLD_RESTART      0x01
#define     CMD_SYSTEM_INIT       0x02
#define     CMD_DC_DATA_DUMP      0x11
#define     CMD_DC_SETTING        0x31
#define     CMD_DLC_SETTING       0x32
#define     CMD_DC_MANUAL_CONTROL 0x21
#define     CMD_DC_SETTING_RCU_ID 0x33
#define     CMD_DC_SETTING_HDAY   0x34
#define     CMD_DC_SETTING_TIME   0x35
#define     CMD_DC_SETTING_HDAY_ALL   0x36

#define     CMD_DC_DAY_REPORT     0X61
#define     CMD_DC_MONTH_REPORT   0X62
#define     CMD_DC_YEAR_REPORT    0X63
#define     CMD_DC_RCU_DAY_REPORT 0X64

#define     CMD_DC_EVENT_HISTORY  0X51
#define     CMD_DC_EVENT_DLC_MEG  0X54
#define     CMD_DC_EVENT_CONTROL  0X53
#define     CMD_DC_EVENT_ON_OFF   0X52

#define     CMD_DLC_CONTROL       0X41
#define     CMD_DLC_CONTROL_BEF   0X42
#define     CMD_DLC_CONTROL_AFT   0X43

typedef unsigned short	word;
typedef unsigned char 	byte;
//---------------------------------------------------------------------------

typedef struct bitField8{
	unsigned int flag1:1;
	unsigned int flag2:1;
	unsigned int flag3:1;
	unsigned int flag4:1;
	unsigned int flag5:1;
	unsigned int flag6:1;
	unsigned int flag7:1;
	unsigned int flag8:1;
} bitField8;

typedef struct bitField16{
	unsigned int flag1:1;
	unsigned int flag2:1;
	unsigned int flag3:1;
	unsigned int flag4:1;
	unsigned int flag5:1;
	unsigned int flag6:1;
	unsigned int flag7:1;
	unsigned int flag8:1;
	unsigned int flag9:1;
	unsigned int flag10:1;
	unsigned int flag11:1;
	unsigned int flag12:1;
	unsigned int flag13:1;
	unsigned int flag14:1;
	unsigned int flag15:1;
	unsigned int flag16:1;
} bitField16;


#define CTRL_FIRST      flag8
#define CTRL_FINAL      flag7
#define CTRL_DIR        flag6
#define CTRL_R_W        flag5
#define CTRL_CREQ       flag4
#define CTRL_ACK        flag3
#define CTRL_RESERVED1  flag2
#define CTRL_RESERVED2  flag1


#define LOAD1           flag1
#define LOAD2           flag2
#define LOAD3           flag3
#define LOAD4           flag4
#define LOAD5           flag5
#define LOAD6           flag6
#define LOAD7           flag7
#define LOAD8           flag8
#define LOAD9           flag9
#define LOAD10          flag10
#define LOAD11          flag11
#define LOAD12          flag12
#define LOAD13          flag13
#define LOAD14          flag14
#define LOAD15          flag15
#define LOAD16          flag16

typedef struct PCInterfaceInfo {

	char    fEndOfFrame;

	char    *FwTx;
	char    *FwRx;
	word    FwTxCnt;
	word    FwRxCnt;
	word    FwTxLen;
	word    FwRxLen;

	char    *OrgTx;
	char    *OrgRx;
	word    OrgTxCnt;
	word    OrgRxCnt;
	word    OrgTxLen;
	word    OrgRxLen;

  char    BCC_TX_CMD;
  char    BCC_RX_CMD;
  char    BCC_TX_ID;
  char    BCC_RX_ID;
  char    BCC_VALUE;

  bool    Flag;
  int     RxTimeOutFlag;
  long    Cnt;
  long    Dlecnt;
  int		  CommMode;  

  char    StartFlag;
  word    FrameLengthTx;
  char    FrameControlTx;
  char    FrameChangeCMDTx;
  char    FrameCMDTx;
  word    FrmaeCrcTx;

  word    FrameLengthRx;
  char    FrameControlRx;
  char    FrameChangeCMDRx;
  char    FrameCMDRx;
  word    FrameCrcRx;
}PCInterfaceInfo;
//---------------------------------------------------------------------------
extern PCInterfaceInfo PCInterface;
extern char 	FwTxBuf[BUFFSIZE];
extern char 	FwRxBuf[BUFFSIZE];
extern char 	OrgTxBuf[BUFFHALFSIZE];
extern char 	OrgRxBuf[BUFFHALFSIZE];
//---------------------------------------------------------------------------
char InitPCInterfaceInfoTxRxBuffer(
	PCInterfaceInfo *,
	char *, word, char *, word, char *, word, char *, word
);
char TempCrc( char value , word *crc );
char MakeCRC( PCInterfaceInfo *frm , word *crc );
char CheckCRC( PCInterfaceInfo *frm , word *crc );

char MakeProtocol( PCInterfaceInfo *frm );
char CheckProtocol( PCInterfaceInfo *frm );
char makeCRC( PCInterfaceInfo *frm );
char checkCRC( PCInterfaceInfo *frm );
void ConvertCRCFrameInfo( PCInterfaceInfo *frm );
char MakeBCC( PCInterfaceInfo *frm );
char CheckBCC( PCInterfaceInfo *frm );
char makeBCC( PCInterfaceInfo *frm );
char checkBCC( PCInterfaceInfo *frm );

short ShortDataConvert(char *TempBuffer, word *TransferCount);
word WordDataConvert(char *TempBuffer, word *TransferCount);
long LongDataConvert(char *TempBuffer, word *TransferCount);
unsigned long ULongDataConvert(char *TempBuffer, word *TransferCount);
void TrasferShortDataMake(word *ConvertCount, char *TempBuffer, short ReadData);
void TrasferWordDataMake(word *ConvertCount, char *TempBuffer, word ReadData);
void TrasferLongDataMake(word *ConvertCount, char *TempBuffer, long ReadData);
word DBLSLib_GenerationDnpCRC(byte *pBuff, word count);
bool DBLSLib_CheckDnpCRC(byte *pBuff, word count);
void DBLSLib_SetDnpCRC(byte *pBuff, word count);
//---------------------------------------------------------------------------
#endif



