#include "CommData.h"
CommDataInterface CommData;
//---------------------------------------------------------------------------
void DCDataDump()
{
  word Count = 0;
  PCInterface.OrgTx[Count++] = PCInterface.BCC_TX_CMD;
  TrasferWordDataMake(&Count, PCInterface.OrgTx, (word)CommData.UserId);

  TrasferLongDataMake(&Count, PCInterface.OrgTx, CommData.PresentPower);
  TrasferLongDataMake(&Count, PCInterface.OrgTx, CommData.BasePower);
  TrasferLongDataMake(&Count, PCInterface.OrgTx, CommData.EstimatePower);
  TrasferLongDataMake(&Count, PCInterface.OrgTx, CommData.TargetPower);
  TrasferWordDataMake(&Count, PCInterface.OrgTx, CommData.DemandTime);
/*
  if((CommData.UserId == 3038)||(CommData.UserId == 3010)||
    (CommData.UserId == 3011)||(CommData.UserId == 3005)||
    (CommData.UserId == 3019)||(CommData.UserId == 3006)||
    (CommData.UserId == 3013)||(CommData.UserId >= 3108))
  {
    TrasferLongDataMake(&Count, PCInterface.OrgTx, CommData.RCULoadStatus);
  }
  else
  {
    long nData;
    nData = (long)(CommData.RCULoadStatus << 24 )& 0xff000000 ;
  	nData |= (long)(CommData.RCULoadStatus << 16)&0xff0000;
	  nData |= (long)(CommData.RCULoadStatus << 8) &0xff00;
  	nData |= (long)(CommData.RCULoadStatus&0xff) ;
	  nData = nData & 0xffffffff ;
    TrasferLongDataMake(&Count, PCInterface.OrgTx, nData);
  }
*/
  PCInterface.OrgTx[Count++] = CommData.AlarmFlag;
  PCInterface.OrgTx[Count++] = CommData.ControlModeFlag;//Restart Flag
  TrasferWordDataMake(&Count, PCInterface.OrgTx, CommData.DCYear);
  PCInterface.OrgTx[Count++] = CommData.DCMonth;
  PCInterface.OrgTx[Count++] = CommData.DCDay;
  PCInterface.OrgTx[Count++] = CommData.DCHour;
  PCInterface.OrgTx[Count++] = CommData.DCMinute;
  PCInterface.OrgTx[Count++] = CommData.DCSec;
    PCInterface.OrgTx[Count++] = (int)CommData.RCUNumber;
    long nData;
    nData = (long)(CommData.RCULoadStatus << 24 )& 0xff000000 ;
  	nData |= (long)(CommData.RCULoadStatus << 16)&0xff0000;
	  nData |= (long)(CommData.RCULoadStatus << 8) &0xff00;
  	nData |= (long)(CommData.RCULoadStatus&0xff) ;
	  nData = nData & 0xffffffff ;
    TrasferLongDataMake(&Count, PCInterface.OrgTx, nData);

    nData = (long)(CommData.RCUCommStatus << 24 )& 0xff000000 ;
  	nData |= (long)(CommData.RCUCommStatus << 16)&0xff0000;
	  nData |= (long)(CommData.RCUCommStatus << 8) &0xff00;
  	nData |= (long)(CommData.RCUCommStatus&0xff) ;
	  nData = nData & 0xffffffff ;

    TrasferLongDataMake(&Count, PCInterface.OrgTx, nData);

  for(int i=0;i<(int)CommData.RCUNumber;i++)
  {
    TrasferLongDataMake(&Count, PCInterface.OrgTx, CommData.RCUVoltageA[i]);
    TrasferLongDataMake(&Count, PCInterface.OrgTx, CommData.RCUCurrentA[i]);
    TrasferLongDataMake(&Count, PCInterface.OrgTx, CommData.RCUVAPowerA[i]);
  }
  PCInterface.OrgTxCnt = Count;
}
//---------------------------------------------------------------------------
void DCSettingData()
{
  word Count = 0;

  TrasferWordDataMake(&Count, PCInterface.OrgTx, CommData.SetID);
  TrasferLongDataMake(&Count, PCInterface.OrgTx, CommData.SetTargetPower);
  TrasferWordDataMake(&Count, PCInterface.OrgTx, CommData.SetPulse);
  TrasferLongDataMake(&Count, PCInterface.OrgTx, CommData.SetCPTRatio);
  PCInterface.OrgTx[Count++] = CommData.SetServerCommInterval;
  PCInterface.OrgTx[Count++] = CommData.SetLoadControlMode;
  PCInterface.OrgTx[Count++] = CommData.SetControlOnTime;
  PCInterface.OrgTx[Count++] = CommData.SetControlOffTime;
  TrasferWordDataMake(&Count, PCInterface.OrgTx, CommData.SetRCUTimeOut);
  PCInterface.OrgTx[Count++] = CommData.SetRCURetryNum;
  PCInterface.OrgTx[Count++] = CommData.SetDualPulseFlag;
  PCInterface.OrgTx[Count++] = CommData.SetDirectLoad1Enabled;
  PCInterface.OrgTx[Count++] = CommData.SetDirectLoad2Enabled;
  PCInterface.OrgTx[Count++] = CommData.SetControlMethod;
  PCInterface.OrgTx[Count++] = CommData.SetLoadControlStartTime;
  PCInterface.OrgTx[Count++] = CommData.SetAlarmEnabled;

  PCInterface.OrgTxCnt = Count;
}
//---------------------------------------------------------------------------
void DLCSettingData()
{
  word Count = 0;
  
  PCInterface.OrgTx[Count++] = CommData.SetTCPConnectMode;
  PCInterface.OrgTx[Count++] = CommData.SetLocalIP1;
  PCInterface.OrgTx[Count++] = CommData.SetLocalIP2;
  PCInterface.OrgTx[Count++] = CommData.SetLocalIP3;
  PCInterface.OrgTx[Count++] = CommData.SetLocalIP4;
  PCInterface.OrgTx[Count++] = CommData.SetSubnetMask1;
  PCInterface.OrgTx[Count++] = CommData.SetSubnetMask2;
  PCInterface.OrgTx[Count++] = CommData.SetSubnetMask3;
  PCInterface.OrgTx[Count++] = CommData.SetSubnetMask4;
  PCInterface.OrgTx[Count++] = CommData.SetGateway1;
  PCInterface.OrgTx[Count++] = CommData.SetGateway2;
  PCInterface.OrgTx[Count++] = CommData.SetGateway3;
  PCInterface.OrgTx[Count++] = CommData.SetGateway4;
  TrasferWordDataMake(&Count, PCInterface.OrgTx, CommData.SetLocalPort);
  PCInterface.OrgTx[Count++] = CommData.SetServerIP1;
  PCInterface.OrgTx[Count++] = CommData.SetServerIP2;
  PCInterface.OrgTx[Count++] = CommData.SetServerIP3;
  PCInterface.OrgTx[Count++] = CommData.SetServerIP4;
  TrasferWordDataMake(&Count, PCInterface.OrgTx, CommData.SetServerPort);
  PCInterface.OrgTx[Count++] = CommData.SetTimeOut;
  PCInterface.OrgTx[Count++] = CommData.SetMuxType;
  TrasferWordDataMake(&Count, PCInterface.OrgTx, CommData.SetWaterMark);
  for(int i=0;i<15;i++)
  {
    PCInterface.OrgTx[Count++] = CommData.SetADSLUserID[i];
  }
  for(int i=0;i<8;i++)
  {
    PCInterface.OrgTx[Count++] = CommData.SetADSLUserPassWd[i];
  }

  PCInterface.OrgTxCnt = Count;
}
//---------------------------------------------------------------------------
