//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ScktComp.hpp>
#include <ExtCtrls.hpp>
#include <ComCtrls.hpp>
#include <Grids.hpp>
#include <time.h>
#include <Buttons.hpp>
#include "CSPIN.h"
//---------------------------------------------------------------------------
typedef struct TimeData{
    int Hyear;
    int Hmon;
    int Hday;
    int Hhour;
    int Hmin;
    int Hsec;
}TimeData;

class TMainForm : public TForm
{
__published:	// IDE-managed Components
    TButton *Button1;
    TClientSocket *ClientSocket1;
    TButton *Button2;
    TButton *Button3;
    TEdit *Edit2;
    TEdit *Edit3;
    TLabel *Label1;
    TLabel *Label2;
    TShape *Shape1;
  TTimer *Timer1;
  TLabel *Label3;
  TNotebook *Notebook1;
  TBevel *Bevel1;
  TLabel *Label6;
  TLabel *Label7;
  TLabel *Label8;
  TLabel *Label9;
  TLabel *Label10;
  TLabel *Label11;
  TLabel *Label12;
  TLabel *Label13;
  TLabel *Label14;
  TLabel *Label15;
  TLabel *Label16;
  TLabel *Label17;
  TLabel *Label18;
  TLabel *Label21;
  TLabel *Label30;
  TLabel *Label38;
  TLabel *Label39;
  TEdit *EditDCId;
  TEdit *EditEstimatePower;
  TEdit *EditTargetPower;
  TEdit *EditPresentPower;
  TEdit *EditBasePower;
  TEdit *EditDemandTime;
  TEdit *EditAlarmFlag;
  TEdit *EditControlFlag;
  TEdit *EditDLCCommStatus;
  TEdit *EditLoadNum;
  TEdit *EditRCUComm;
    TEdit *EditRCULoad1;
  TEdit *EditDCTime;
  TEdit *EditVoltageA;
  TEdit *EditCurrentA;
  TEdit *EditVAPowerA;
  TEdit *EditDCLoad1;
  TEdit *EditDCLoad2;
  TGroupBox *GroupBox3;
  TLabel *Label40;
  TLabel *Label41;
  TEdit *EditControlValue;
  TEdit *EditControlMode;
  TGroupBox *GroupBox6;
  TMemo *MemoMessage;
  TMemo *MemoRxData;
  TTimer *TimerReceive;
  TBitBtn *BitBtn1;
  TSpeedButton *SpeedButton3;
  TCSpinButton *CSpinButton1;
  TButton *ButtonIdStart;
  TMemo *MemoTxData;
  TGroupBox *GroupBoxAck;
  TButton *Button4;
  TLabel *Label4;
  TEdit *EditControlEnabled;
  TMemo *MemoRxData2;
  TButton *Button5;
  TGroupBox *GroupBox1;
  TLabel *Label5;
  TEdit *EditSettingCommInterval;
  TEdit *EditSettingIP1;
  TLabel *Label42;
  TLabel *Label43;
  TEdit *EditSettingIP2;
  TLabel *Label44;
  TEdit *EditSettingIP3;
  TLabel *Label45;
  TEdit *EditSettingIP4;
  TLabel *Label46;
  TEdit *EditSettingPort;
  TLabel *Label47;
  TEdit *EditSettingID;
  TLabel *Label48;
  TEdit *EditSettingSpeed;
  TLabel *Label49;
  TEdit *EditSettingTimeOut;
  TLabel *Label50;
  TEdit *EditSettingYear;
  TLabel *Label51;
  TEdit *EditSettingMon;
  TEdit *EditSettingDay;
  TLabel *Label52;
  TLabel *Label53;
  TEdit *EditSettingHour;
  TLabel *Label54;
  TEdit *EditSettingMin;
  TLabel *Label55;
  TEdit *EditSettingSec;
    TLabel *Label19;
    TEdit *EditRCULoad2;
    TLabel *Label20;
    TEdit *EditRCULoad3;
    TLabel *Label22;
    TEdit *EditRCULoad4;
    TButton *Button6;
    TEdit *Edit1;
    void __fastcall Button1Click(TObject *Sender);
    void __fastcall ClientSocket1Read(TObject *Sender,
          TCustomWinSocket *Socket);
    void __fastcall Button2Click(TObject *Sender);
    void __fastcall Button3Click(TObject *Sender);
  void __fastcall Timer1Timer(TObject *Sender);
  void __fastcall ClientSocket1Error(TObject *Sender,
          TCustomWinSocket *Socket, TErrorEvent ErrorEvent,
          int &ErrorCode);
  void __fastcall FormCreate(TObject *Sender);
  void __fastcall TimerReceiveTimer(TObject *Sender);
  void __fastcall BitBtn1Click(TObject *Sender);
  void __fastcall SpeedButton3Click(TObject *Sender);
  void __fastcall CSpinButton1DownClick(TObject *Sender);
  void __fastcall CSpinButton1UpClick(TObject *Sender);
  void __fastcall ButtonIdStartClick(TObject *Sender);
  void __fastcall Button4Click(TObject *Sender);
  void __fastcall Button5Click(TObject *Sender);
    void __fastcall Button6Click(TObject *Sender);

private:	// User declarations
  DWORD ReceiveCount;
  unsigned char TempCommBuffer[4000];
  void __fastcall DCDataDumpDataMake();
  void __fastcall DataSend();
  TimeData CurrentTime;
  void __fastcall DataProcess2(DWORD nBytesRead, unsigned char *Inbuff);
  void __fastcall DataProcess(DWORD nBytesRead, unsigned char *Inbuff);

  int DemandTargetPower;
  int DemandEstimatePower;
  int DemandBasePower;
  int DemandPresentPower;
  int DemandTime;
  int DemandLoadNum;
  int DemandCommInterval;
  unsigned long DemandLoadStatus;


  String MessageString;
  int TxCommand;
  int RxCommand;
  int TxCommandCount;
  int RxCommandCount;
  void __fastcall WriteTxMessage(String MsgString);
  void __fastcall WriteRxMessage(String MsgString);
  void __fastcall InfoSave(int UserId);
public:		// User declarations
    __fastcall TMainForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TMainForm *MainForm;
//---------------------------------------------------------------------------
#endif
