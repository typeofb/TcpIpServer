//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include <stdio.h>
#include <stdlib.h>
#include "Unit1.h"
#include "Comm.h"
#include "CommData.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "CSPIN"
#pragma resource "*.dfm"
TMainForm *MainForm;
//---------------------------------------------------------------------------
__fastcall TMainForm::TMainForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void CurrentTimeFuction(TimeData *CurrentTime)
{
    char str[80];
    struct tm *time_now;
    time_t secs_now;

    time(&secs_now);
    time_now = localtime(&secs_now);

    CurrentTime->Hyear = time_now->tm_year+1900;
    CurrentTime->Hmon = time_now->tm_mon+1;
    CurrentTime->Hday = time_now->tm_mday;
    CurrentTime->Hhour = time_now->tm_hour;
    CurrentTime->Hmin = time_now->tm_min;
    CurrentTime->Hsec = time_now->tm_sec;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::FormCreate(TObject *Sender)
{
  char szBuf[20] = {0,};
  String TempString;
  int TempID;
  char TempStr[100] = {0,};

  ReceiveCount = 0;
  InitPCInterfaceInfoTxRxBuffer(
    &PCInterface,
    FwTxBuf, BUFFSIZE, FwRxBuf, BUFFSIZE,
    OrgTxBuf, BUFFHALFSIZE, OrgRxBuf, BUFFHALFSIZE
  );
	GetPrivateProfileString("DCID" , "DLCID" , "3000" , szBuf , 10 , "Serial.ini");
  EditDCId->Text = szBuf;
  EditSettingID->Text = szBuf;

  CurrentTimeFuction(&CurrentTime);
  EditSettingYear->Text = CurrentTime.Hyear;
  EditSettingMon->Text = CurrentTime.Hmon;
  EditSettingDay->Text = CurrentTime.Hday;
  EditSettingHour->Text = CurrentTime.Hhour;
  EditSettingMin->Text = CurrentTime.Hmin;
  EditSettingSec->Text = CurrentTime.Hsec;


  sprintf(TempStr,"DC_ID%d", StrToInt(EditDCId->Text));
  GetPrivateProfileString(TempStr , "TargetPower", "3000" , szBuf , 10 , "Serial.ini");
  DemandTargetPower = atoi(szBuf);
  DemandEstimatePower = 0;
  DemandBasePower = 0;
  DemandPresentPower = 0;
  DemandTime = 0;
  GetPrivateProfileString(TempStr , "LoadNumber",  "5" , szBuf , 10 , "Serial.ini");
  DemandLoadNum = atoi(szBuf);
  GetPrivateProfileString(TempStr , "LoadStatus",  "4294967295" , szBuf , 10 , "Serial.ini");
  DemandLoadStatus = _atoi64(szBuf);
  sprintf(TempStr,"0x%x", DemandLoadStatus);
//  EditRCULoad->Text = TempStr;

  GetPrivateProfileString(TempStr , "CommInterval", "1" , szBuf , 10 , "Serial.ini");
  DemandCommInterval = atoi(szBuf);

  EditTargetPower->Text = DemandTargetPower;
  EditLoadNum->Text = DemandLoadNum;
  EditSettingCommInterval->Text = DemandCommInterval;
  Timer1->Interval = DemandCommInterval*1000;

  TxCommand = CMD_BCC_MONITOR;
  TxCommandCount = 0;
  RxCommandCount = 0;
  Notebook1->ActivePage = "Main";

  TempID = StrToInt(EditDCId->Text);
  TempID++;
  InfoSave(TempID);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::Timer1Timer(TObject *Sender)
{
  CurrentTimeFuction(&CurrentTime);
  if(ClientSocket1->Active == true)
  {
    Label3->Caption = "Connect";
  }
  else
  {
    Label3->Caption = "DisConnect";
    Button2Click(Sender);
  }

  DemandEstimatePower = DemandTargetPower + DemandTargetPower*0.1;
  DemandTime = (CurrentTime.Hmin*60 + CurrentTime.Hsec)%900;
  if(DemandTime != 0)
    DemandBasePower = DemandTime*(DemandTargetPower/900);
  DemandPresentPower = DemandBasePower + DemandBasePower*0.1;

  EditPresentPower->Text = DemandPresentPower;
  EditBasePower->Text = DemandBasePower;
  EditEstimatePower->Text = DemandEstimatePower;
  EditDemandTime->Text = DemandTime;

  if(Label3->Caption == "Connect")
  {
    Button1Click(Sender);
  }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::Button1Click(TObject *Sender)
{
  if(MemoRxData->Lines->Count > 500)
    MemoRxData->Clear();

  if(MemoTxData->Lines->Count > 500)
    MemoTxData->Clear();

  CommData.UserId = StrToInt(EditDCId->Text);

  if(TxCommand == CMD_BCC_MONITOR)
  {
    MessageString = "CMD_BCC_MONITOR Command Send";
    WriteTxMessage(MessageString);
    PCInterface.BCC_TX_CMD = CMD_BCC_MONITOR;
    DCDataDumpDataMake();
    DCDataDump();
    DataSend();
  }
  else if(TxCommand == CMD_ACK_CONFIRM)
  {
    MessageString = "CMD_ACK_CONFIRM Command Send";
    WriteTxMessage(MessageString);
    PCInterface.BCC_TX_CMD = CMD_ACK_CONFIRM;
    word Count = 0;
    PCInterface.OrgTx[Count++] = PCInterface.BCC_TX_CMD;
    TrasferWordDataMake(&Count, PCInterface.OrgTx, (word)CommData.UserId);
    PCInterface.OrgTxCnt = Count;
    DataSend();
    TxCommand = CMD_BCC_MONITOR;
  }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::WriteTxMessage(String MsgString)
{
  String TempString;
  if(++TxCommandCount > 10000)
    TxCommandCount = 0;

  TempString = "[";
  TempString += TxCommandCount;
  TempString += "] ";
  TempString += MsgString;
  MemoTxData->Lines->Add(TempString);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::WriteRxMessage(String MsgString)
{
  String TempString;
  if(++RxCommandCount > 10000)
    RxCommandCount = 0;

  TempString = "[";
  TempString += RxCommandCount;
  TempString += "] ";
  TempString += MsgString;
  MemoRxData->Lines->Add(TempString);
  MemoRxData2->Lines->Add(TempString);  
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::ClientSocket1Read(TObject *Sender,
      TCustomWinSocket *Socket)
{
  if(MemoRxData->Lines->Count > 500)
    MemoRxData->Clear();

  int DataLength;
  if( Socket->ReceiveLength())
  {
    DataLength = Socket->ReceiveLength();
    DataProcess2(DataLength, (unsigned char *)Socket->ReceiveText().c_str());
  }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::DataProcess2(DWORD nBytesRead, unsigned char *Inbuff)
{
  TimerReceive->Enabled = false;
  for(DWORD i=0;i<nBytesRead;i++)
  {
    if(ReceiveCount < 15000)
    {
      TempCommBuffer[ReceiveCount++] = Inbuff[i];
    }
    else
    {
      ReceiveCount = 0;
    }
  }
  TimerReceive->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::Button2Click(TObject *Sender)
{
  ClientSocket1->Close();
  ClientSocket1->Address = Edit2->Text;
  ClientSocket1->Port = atoi(Edit3->Text.c_str());
  ClientSocket1->Open();
  Timer1->Interval = StrToInt(Edit1->Text);
  Timer1->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::Button3Click(TObject *Sender)
{
  Timer1->Enabled = false;
  ClientSocket1->Close();
  Label3->Caption = "DisConnect";
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::ClientSocket1Error(TObject *Sender,
      TCustomWinSocket *Socket, TErrorEvent ErrorEvent, int &ErrorCode)
{

  int TempErrorCode;
    TempErrorCode = ErrorCode;
    ErrorCode = 0;

  if(ErrorEvent==eeConnect)
  {
    Socket->Close();
  }
  else
  {
    Socket->Close();
  }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::DCDataDumpDataMake()
{
  CommData.UserId = StrToInt(EditDCId->Text);
  CommData.PresentPower = StrToInt(EditPresentPower->Text);
  CommData.BasePower = StrToInt(EditBasePower->Text);
  CommData.EstimatePower = StrToInt(EditEstimatePower->Text);
  CommData.TargetPower = StrToInt(EditTargetPower->Text);
  CommData.DemandTime = StrToInt(EditDemandTime->Text);
  CommData.AlarmFlag = StrToInt(EditAlarmFlag->Text);
  CommData.ControlModeFlag = StrToInt(EditControlFlag->Text);
  CommData.DLCCommStatus = StrToInt(EditDLCCommStatus->Text);
  CommData.RCUCommStatus = StrToInt(EditRCUComm->Text);
  CommData.RCULoadStatus = StrToInt(EditRCULoad1->Text);
  CommData.DCLoad1 = StrToInt(EditDCLoad1->Text);
  CommData.DCLoad2 = StrToInt(EditDCLoad2->Text);  
  CommData.DCYear = CurrentTime.Hyear;
  CommData.DCMonth = CurrentTime.Hmon;
  CommData.DCDay = CurrentTime.Hday;
  CommData.DCHour = CurrentTime.Hhour;
  CommData.DCMinute = CurrentTime.Hmin;
  CommData.DCSec = CurrentTime.Hsec;

  CommData.RCUNumber = StrToInt(EditLoadNum->Text);

  for(int i=0;i<CommData.RCUNumber;i++)
  {
    CommData.RCUNo[i] = i+1;
        CommData.RCUCurrentA[i] = StrToInt(EditVoltageA->Text);
        CommData.RCUVoltageA[i] = StrToInt(EditCurrentA->Text);


    if((StrToInt(EditRCULoad1->Text) >> i)&0x01 == true)
    {

            CommData.RCUVAPowerA[i] = StrToInt(EditVAPowerA->Text);
    }
    else
    {
      CommData.RCUVAPowerA[i] = 0;
    }
  }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::DataSend()
{
  if(MakeProtocol(&PCInterface) == false)
  {
    ShowMessage("������ ������ �����߽��ϴ�. ");
    return;
  }
  else
  {
    ClientSocket1->Socket->SendBuf(PCInterface.FwTx, PCInterface.FwTxCnt);
  }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::TimerReceiveTimer(TObject *Sender)
{
  TimerReceive->Enabled = false;
  DataProcess(ReceiveCount, TempCommBuffer);
  ReceiveCount = 0;  
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::DataProcess(DWORD nBytesRead, unsigned char *Inbuff)
{
  PCInterface.FwRxCnt = 0;
  word Count = 0;
  word cnt = 0;
  char TempStr[100] = {0,};
  String TempString;
  unsigned long TempLong;
  unsigned long TempLong2;
  int TempID, TempInt;


  for (DWORD i = 0; i < nBytesRead; i++)
  {
    PCInterface.FwRx[PCInterface.FwRxCnt++] = Inbuff[i];
  }

  if(CheckProtocol(&PCInterface) == true)
  {
    PCInterface.FrameCMDRx = PCInterface.OrgRx[cnt++];
    for(int i=0;i<PCInterface.OrgRxCnt;i++)
    {
      PCInterface.OrgTx[i] = PCInterface.OrgRx[i];
    }
    PCInterface.OrgTxCnt = PCInterface.OrgRxCnt;

    if(PCInterface.FrameCMDRx == CMD_BCC_MONITOR)
    {
      MessageString = "CMD_BCC_MONITOR Command Receive";
      WriteRxMessage(MessageString);
    }
    else if(PCInterface.FrameCMDRx == CMD_BCC_TIME_SYNC)
    {
      MessageString = "CMD_BCC_TIME_SYNC Command Receive";
      WriteRxMessage(MessageString);
      MessageString = WordDataConvert(PCInterface.OrgRx, &cnt);
      MessageString = WordDataConvert(PCInterface.OrgRx, &cnt); MessageString += "/";
      MessageString += WordDataConvert(PCInterface.OrgRx, &cnt); MessageString += "/";
      MessageString += WordDataConvert(PCInterface.OrgRx, &cnt); MessageString += "  ";
      MessageString += WordDataConvert(PCInterface.OrgRx, &cnt); MessageString += ":";
      MessageString += WordDataConvert(PCInterface.OrgRx, &cnt); MessageString += ":";
      MessageString += WordDataConvert(PCInterface.OrgRx, &cnt);
      WriteRxMessage(MessageString);       
      TxCommand = CMD_BCC_MONITOR;
    }

    else if(PCInterface.FrameCMDRx == CMD_ACK_CONFIRM)
    {
      MessageString = "CMD_ACK_CONFIRM Command Receive";
      WriteRxMessage(MessageString);
      TxCommand = CMD_BCC_MONITOR;
    }
    else if(PCInterface.FrameCMDRx == CMD_BCC_CONTROL_START)
    {
        int TempEnabled;
        TempID = WordDataConvert(PCInterface.OrgRx, &cnt);
        TempEnabled = PCInterface.OrgRx[cnt++];
      if(CommData.UserId == TempID)
      {
        MessageString = "CMD_BCC_CONTROL_START Command Receive";
        WriteRxMessage(MessageString);
        if( TempEnabled== 1)
          EditControlEnabled->Text = "�����";
        else if(TempEnabled == 0)
          EditControlEnabled->Text = "�������";
        else
          EditControlEnabled->Text = "�˼�����";

        PCInterface.OrgTx[Count++] = CMD_BCC_CONTROL_START;
        TrasferWordDataMake(&Count, PCInterface.OrgTx, (word)TempID);
        if(EditControlEnabled->Text == "�����")
          PCInterface.OrgTx[Count++] = 1;
        else if(EditControlEnabled->Text == "�������")
          PCInterface.OrgTx[Count++] = 0;
        else
          PCInterface.OrgTx[Count++] = 2;
        PCInterface.OrgTxCnt = Count;
        DataSend();
      }
      else
      {
        MessageString = "CMD_BCC_CONTROL_START Command Receive(Id Fail)";
        WriteRxMessage(MessageString);
      }
    }
    else if(PCInterface.FrameCMDRx == CMD_BCC_CONTROL)
    {
      if(CommData.UserId > 4900)
      {
        TempID = WordDataConvert(PCInterface.OrgRx, &cnt);
        if(CommData.UserId == TempID)
        {
          MessageString = "CMD_BCC_CONTROL Command Receive";
          WriteRxMessage(MessageString);
          TempLong = LongDataConvert(PCInterface.OrgRx, &cnt);
          sprintf(TempStr,"0x%x", TempLong);
          EditControlValue->Text = TempStr;

          sprintf(TempStr,"0x%08x", TempLong);
          EditRCULoad1->Text = TempStr;

          PCInterface.OrgTx[Count++] = CMD_BCC_CONTROL;
          TrasferWordDataMake(&Count, PCInterface.OrgTx, (word)CommData.UserId);
          PCInterface.OrgTxCnt = Count;
          DataSend();
        }
        else
        {
          MessageString = "CMD_BCC_CONTROL Command Receive(Id Fail)";
          WriteRxMessage(MessageString);
        }
      }
      else
      {
        MessageString = "CMD_BCC_CONTROL Command Receive";
        WriteRxMessage(MessageString);
        if((int)PCInterface.OrgRx[cnt++] == 2)
          EditControlMode->Text = "������������";
        else if((int)PCInterface.OrgRx[cnt++] == 3)
          EditControlMode->Text = "������������";
        TempLong = LongDataConvert(PCInterface.OrgRx, &cnt);
        EditControlValue->Text = TempLong;

        TempLong2 = StrToInt64(EditRCULoad1->Text);
        TempLong2 = TempLong2 ^ TempLong;

        sprintf(TempStr,"0x%04x", TempLong2);
        EditRCULoad1->Text = TempStr;

        PCInterface.OrgTx[Count++] = CMD_BCC_CONTROL;
        TrasferWordDataMake(&Count, PCInterface.OrgTx, (word)CommData.UserId);
        PCInterface.OrgTxCnt = Count;
        DataSend();
      }
    }
    else if(PCInterface.FrameCMDRx == CMD_MESSAGE)
    {

        TempID = WordDataConvert(PCInterface.OrgRx, &cnt);
        if(CommData.UserId == TempID)
        {
          MessageString = "CMD_MESSAGE Command Receive";
          WriteRxMessage(MessageString);

          MemoMessage->Clear();          
          TempString = "UserID : ";
          TempString += TempID;
          TempString += "  Message Data\r\n" ;
          for(int i=cnt;i<PCInterface.OrgRxCnt;i++)
          {
            TempString += PCInterface.OrgRx[i];
          }
          MemoMessage->Lines->Add(TempString);

          PCInterface.OrgTx[Count++] = CMD_MESSAGE;
          TrasferWordDataMake(&Count, PCInterface.OrgTx, TempID);
          PCInterface.OrgTxCnt = Count;
          DataSend();
        }
    }
    else if(PCInterface.FrameCMDRx == CMD_SETTING_READ)
    {

        TempID = WordDataConvert(PCInterface.OrgRx, &cnt);
        if(CommData.UserId == TempID)
        {
          MessageString = "CMD_SETTING_READ Command Receive";
          WriteRxMessage(MessageString);

          PCInterface.OrgTx[Count++] = CMD_SETTING_READ;
          TrasferWordDataMake(&Count, PCInterface.OrgTx, TempID);
          TrasferWordDataMake(&Count, PCInterface.OrgTx, StrToInt(EditSettingCommInterval->Text));
          PCInterface.OrgTx[Count++] = StrToInt(EditSettingIP1->Text);
          PCInterface.OrgTx[Count++] = StrToInt(EditSettingIP2->Text);
          PCInterface.OrgTx[Count++] = StrToInt(EditSettingIP3->Text);
          PCInterface.OrgTx[Count++] = StrToInt(EditSettingIP4->Text);
          TrasferWordDataMake(&Count, PCInterface.OrgTx, StrToInt(EditSettingPort->Text));
          TrasferWordDataMake(&Count, PCInterface.OrgTx, StrToInt(EditSettingSpeed->Text));
          PCInterface.OrgTx[Count++] = StrToInt(EditSettingTimeOut->Text);
          TrasferWordDataMake(&Count, PCInterface.OrgTx, StrToInt(EditSettingYear->Text));
          TrasferWordDataMake(&Count, PCInterface.OrgTx, StrToInt(EditSettingMon->Text));
          TrasferWordDataMake(&Count, PCInterface.OrgTx, StrToInt(EditSettingDay->Text));
          TrasferWordDataMake(&Count, PCInterface.OrgTx, StrToInt(EditSettingHour->Text));
          TrasferWordDataMake(&Count, PCInterface.OrgTx, StrToInt(EditSettingMin->Text));
          TrasferWordDataMake(&Count, PCInterface.OrgTx, StrToInt(EditSettingSec->Text));
          TrasferWordDataMake(&Count, PCInterface.OrgTx, StrToInt(EditSettingID->Text));

          PCInterface.OrgTxCnt = Count;
          DataSend();
        }


    }
    else if(PCInterface.FrameCMDRx == CMD_SETTING_WRITE)
    {

        TempID = WordDataConvert(PCInterface.OrgRx, &cnt);
        if(CommData.UserId == TempID)
        {
          MessageString = "CMD_SETTING_WRITE Command Receive";
          WriteRxMessage(MessageString);

          EditSettingCommInterval->Text = WordDataConvert(PCInterface.OrgRx, &cnt);
          Timer1->Interval = StrToInt(EditSettingCommInterval->Text)*1000;
          EditSettingIP1->Text = (int)(unsigned char)PCInterface.OrgRx[cnt++];
          EditSettingIP2->Text = (int)(unsigned char)PCInterface.OrgRx[cnt++];
          EditSettingIP3->Text = (int)(unsigned char)PCInterface.OrgRx[cnt++];
          EditSettingIP4->Text = (int)(unsigned char)PCInterface.OrgRx[cnt++];
          EditSettingPort->Text = WordDataConvert(PCInterface.OrgRx, &cnt);
          EditSettingSpeed->Text = WordDataConvert(PCInterface.OrgRx, &cnt);
          EditSettingTimeOut->Text = (int)(unsigned char)PCInterface.OrgRx[cnt++];
          EditSettingYear->Text = WordDataConvert(PCInterface.OrgRx, &cnt);
          EditSettingMon->Text = WordDataConvert(PCInterface.OrgRx, &cnt);
          EditSettingDay->Text = WordDataConvert(PCInterface.OrgRx, &cnt);
          EditSettingHour->Text = WordDataConvert(PCInterface.OrgRx, &cnt);
          EditSettingMin->Text = WordDataConvert(PCInterface.OrgRx, &cnt);
          EditSettingSec->Text = WordDataConvert(PCInterface.OrgRx, &cnt);
          EditSettingID->Text = WordDataConvert(PCInterface.OrgRx, &cnt);
          EditDCId->Text = StrToInt(EditSettingID->Text);

          PCInterface.OrgTx[Count++] = CMD_SETTING_WRITE;
          TrasferWordDataMake(&Count, PCInterface.OrgTx, TempID);

          PCInterface.OrgTxCnt = Count;
          DataSend();
         }
    }
    else if(PCInterface.FrameCMDRx == CMD_BCC_ALARM_CONFIRM)
    {

        TempID = WordDataConvert(PCInterface.OrgRx, &cnt);
        if(CommData.UserId == TempID)
        {
          MessageString = "CMD_BCC_ALARM_CONFIRM Command Receive";
          WriteRxMessage(MessageString);

          MemoMessage->Clear();
          TempString = "�����Ͻ�";
          TempString += WordDataConvert(PCInterface.OrgRx, &cnt);
          TempString += "�� ";
          TempString += (int)(unsigned char)PCInterface.OrgRx[cnt++];
          TempString += "�� ";
          TempString += (int)(unsigned char)PCInterface.OrgRx[cnt++];
          TempString += "�� ";
          TempString += (int)(unsigned char)PCInterface.OrgRx[cnt++];
          TempString += "�� ";
          TempString += (int)(unsigned char)PCInterface.OrgRx[cnt++];
          TempString += "�� ";
          TempString += (int)(unsigned char)PCInterface.OrgRx[cnt++];
          TempString += "�� ";
          MemoMessage->Lines->Add(TempString);

          TempString = "��������ð�";
          TempString += WordDataConvert(PCInterface.OrgRx, &cnt);
          TempString += "�� ";
          TempString += (int)(unsigned char)PCInterface.OrgRx[cnt++];
          TempString += "�� ";
          TempString += (int)(unsigned char)PCInterface.OrgRx[cnt++];
          TempString += "�� ";
          TempString += (int)(unsigned char)PCInterface.OrgRx[cnt++];
          TempString += "�� ";
          TempString += (int)(unsigned char)PCInterface.OrgRx[cnt++];
          TempString += "�� ";
          TempString += (int)(unsigned char)PCInterface.OrgRx[cnt++];
          TempString += "�� ";
          MemoMessage->Lines->Add(TempString);

          TempString = "�������� : ";
          TempString += (int)(unsigned char)PCInterface.OrgRx[cnt++];
          MemoMessage->Lines->Add(TempString);

          TempString = "�����ֱ� : ";
          TempString += (int)(unsigned char)PCInterface.OrgRx[cnt++];
          TempString += "��";
          MemoMessage->Lines->Add(TempString);

          TempString = "������ֱ� : ";
          TempString += (int)(unsigned char)PCInterface.OrgRx[cnt++];
          TempString += "��";
          MemoMessage->Lines->Add(TempString);

          PCInterface.OrgTx[Count++] = CMD_BCC_ALARM_CONFIRM;
          TrasferWordDataMake(&Count, PCInterface.OrgTx, TempID);

          PCInterface.OrgTxCnt = Count;
          DataSend();

      }

    }
    else if(PCInterface.FrameCMDRx == CMD_BCC_CONTROL_RESULT)
    {

        TempID = WordDataConvert(PCInterface.OrgRx, &cnt);
        if(CommData.UserId == TempID)
        {
          MessageString = "������� ���� ����";
          WriteRxMessage(MessageString);

          PCInterface.OrgTx[Count++] = CMD_BCC_CONTROL_RESULT;
          TrasferWordDataMake(&Count, PCInterface.OrgTx, CommData.UserId);

          PCInterface.OrgTxCnt = Count;
          DataSend();
        }
    }

    else if(PCInterface.FrameCMDRx == CMD_EVENT_REPORT)
    {
      TempID = WordDataConvert(PCInterface.OrgRx, &cnt);
      MessageString = "CMD_EVENT_REPORT Command Receive";
      WriteRxMessage(MessageString);

      TempString = "���밡 ID(CMD_EVENT_REPORT):";
      TempString += TempID;
      MemoMessage->Lines->Add(TempString);

      PCInterface.OrgTx[Count++] = CMD_EVENT_REPORT;
      TrasferWordDataMake(&Count, PCInterface.OrgTx, TempID);
      for(int i=0;i<50;i++)
      {
        if(i%6 == 0 )
        {
          TrasferWordDataMake(&Count, PCInterface.OrgTx, 2010);
          PCInterface.OrgTx[Count++] = 5;
          PCInterface.OrgTx[Count++] = 17;
          PCInterface.OrgTx[Count++] = random(24);
          PCInterface.OrgTx[Count++] = random(60);
          PCInterface.OrgTx[Count++] = random(60);
          PCInterface.OrgTx[Count++] = 0x01;
          TrasferWordDataMake(&Count, PCInterface.OrgTx, random(16));
        }
        else if(i%6 == 1 )
        {
          TrasferWordDataMake(&Count, PCInterface.OrgTx, 2010);
          PCInterface.OrgTx[Count++] = 5;
          PCInterface.OrgTx[Count++] = 17;
          PCInterface.OrgTx[Count++] = random(24);
          PCInterface.OrgTx[Count++] = random(60);
          PCInterface.OrgTx[Count++] = random(60);
          PCInterface.OrgTx[Count++] = 0x02;
          TrasferWordDataMake(&Count, PCInterface.OrgTx, random(16));
        }
        else if(i%6 == 2 )
        {
          TrasferWordDataMake(&Count, PCInterface.OrgTx, 2010);
          PCInterface.OrgTx[Count++] = 5;
          PCInterface.OrgTx[Count++] = 17;
          PCInterface.OrgTx[Count++] = random(24);
          PCInterface.OrgTx[Count++] = random(60);
          PCInterface.OrgTx[Count++] = random(60);
          PCInterface.OrgTx[Count++] = 0x03;
          TrasferWordDataMake(&Count, PCInterface.OrgTx, random(16));
        }
        else if(i%6 == 3 )
        {
          TrasferWordDataMake(&Count, PCInterface.OrgTx, 2010);
          PCInterface.OrgTx[Count++] = 5;
          PCInterface.OrgTx[Count++] = 17;
          PCInterface.OrgTx[Count++] = random(24);
          PCInterface.OrgTx[Count++] = random(60);
          PCInterface.OrgTx[Count++] = random(60);
          PCInterface.OrgTx[Count++] = 0x04;
          TrasferWordDataMake(&Count, PCInterface.OrgTx, random(16));
        }
        else if(i%6 == 4 )
        {
          TrasferWordDataMake(&Count, PCInterface.OrgTx, 2010);
          PCInterface.OrgTx[Count++] = 5;
          PCInterface.OrgTx[Count++] = 17;
          PCInterface.OrgTx[Count++] = random(24);
          PCInterface.OrgTx[Count++] = random(60);
          PCInterface.OrgTx[Count++] = random(60);
          PCInterface.OrgTx[Count++] = 0x05;
          TrasferWordDataMake(&Count, PCInterface.OrgTx, random(16));
        }
        else if(i%6 == 5 )
        {
          TrasferWordDataMake(&Count, PCInterface.OrgTx, 2010);
          PCInterface.OrgTx[Count++] = 5;
          PCInterface.OrgTx[Count++] = 17;
          PCInterface.OrgTx[Count++] = random(24);
          PCInterface.OrgTx[Count++] = random(60);
          PCInterface.OrgTx[Count++] = random(60);
          PCInterface.OrgTx[Count++] = 0x06;
          TrasferWordDataMake(&Count, PCInterface.OrgTx, random(16));
        }
      }

      PCInterface.OrgTxCnt = Count;
      DataSend();
    }

    else if(PCInterface.FrameCMDRx == CMD_DAILY_REPORT)
    {
      MemoRxData->Lines->Add("CMD_DAILY_REPORT Command Receive");

       TempID = WordDataConvert(PCInterface.OrgRx, &cnt);
      TempString = "���밡 ID:";
      TempString += TempID;
      MemoMessage->Lines->Add(TempString);

      int TempYear, TempMonth, TempDay, TempHour;
      TempYear = WordDataConvert(PCInterface.OrgRx, &cnt);
      TempString = TempYear;
      TempString +="��";
      TempMonth = (int)PCInterface.OrgRx[cnt++];
      TempString += TempMonth;
      TempString +="��";
      TempDay = (int)PCInterface.OrgRx[cnt++];
      TempString += TempDay;
      TempString +="��";
      MemoMessage->Lines->Add(TempString);

      PCInterface.OrgTx[Count++] = CMD_DAILY_REPORT;
      TrasferWordDataMake(&Count, PCInterface.OrgTx, (word)TempID);
      TrasferWordDataMake(&Count, PCInterface.OrgTx, (word)TempYear);
      PCInterface.OrgTx[Count++] = TempMonth;
      PCInterface.OrgTx[Count++] = TempDay;
      TrasferLongDataMake(&Count, PCInterface.OrgTx, 8000);
      for(int i=0;i<24;i++)
      {
        TrasferLongDataMake(&Count, PCInterface.OrgTx, 78400);
        TrasferLongDataMake(&Count, PCInterface.OrgTx, 123400);
        TrasferLongDataMake(&Count, PCInterface.OrgTx, 567800);
        TrasferLongDataMake(&Count, PCInterface.OrgTx, 512300);
      }

      PCInterface.OrgTxCnt = Count;
      DataSend();
    }
    else if(PCInterface.FrameCMDRx == CMD_15_POWER)
    {
      MemoRxData->Lines->Add("RMU 15�� �������� Command Receive");

       TempID = WordDataConvert(PCInterface.OrgRx, &cnt);
      TempString = "���밡 ID:";
      TempString += TempID;
      MemoMessage->Lines->Add(TempString);

      int TempYear, TempMonth, TempDay, TempHour;
      int TempRMU;
      TempYear = WordDataConvert(PCInterface.OrgRx, &cnt);
      TempString = TempYear;
      TempString += "��";
      TempMonth = (int)PCInterface.OrgRx[cnt++];
      TempString += TempMonth;
      TempString += "��";
      TempDay = (int)PCInterface.OrgRx[cnt++];
      TempString += TempDay;
      TempString += "��, RMU NO.=";
      TempRMU = (int)PCInterface.OrgRx[cnt++];
      TempString += TempRMU;
      MemoMessage->Lines->Add(TempString);

      PCInterface.OrgTx[Count++] = CMD_15_POWER;
      TrasferWordDataMake(&Count, PCInterface.OrgTx, (word)TempID);
      TrasferWordDataMake(&Count, PCInterface.OrgTx, (word)TempYear);
      PCInterface.OrgTx[Count++] = TempMonth;
      PCInterface.OrgTx[Count++] = TempDay;
      PCInterface.OrgTx[Count++] = TempRMU;      

      for(int i=0;i<24;i++)
      {
        TrasferLongDataMake(&Count, PCInterface.OrgTx, 111111);
        TrasferLongDataMake(&Count, PCInterface.OrgTx, 222222);
        TrasferLongDataMake(&Count, PCInterface.OrgTx, 333333);
        TrasferLongDataMake(&Count, PCInterface.OrgTx, 444444);
      }
      PCInterface.OrgTxCnt = Count;
      DataSend();      
    }

    else if(PCInterface.FrameCMDRx == CMD_MONTHLY_REPORT)
    {
      MemoRxData->Lines->Add("CMD_MONTHLY_REPORT Command Receive");
      TempID = WordDataConvert(PCInterface.OrgRx, &cnt);
      TempString = "���밡 ID(CMD_MONTHLY_REPORT):";
      TempString += TempID;
      MemoMessage->Lines->Add(TempString);

      int TempMonth, TempDay, TempHour;

      TempString = WordDataConvert(PCInterface.OrgRx, &cnt);
      TempString +="��";
      TempMonth = (int)PCInterface.OrgRx[cnt++];
      TempString += TempMonth;
      TempString +="��";
      MemoMessage->Lines->Add(TempString);

      PCInterface.OrgTx[Count++] = CMD_MONTHLY_REPORT;
      TrasferWordDataMake(&Count, PCInterface.OrgTx, (word)TempID);
      PCInterface.OrgTx[Count++] = TempMonth;

      for(int i=0;i<31;i++)
      {
        TrasferLongDataMake(&Count, PCInterface.OrgTx, i*100000);
      }

      PCInterface.OrgTxCnt = Count;
      DataSend();
    }
    else if(PCInterface.FrameCMDRx == CMD_YEARLY_REPORT)
    {
      MemoRxData->Lines->Add("CMD_YEARLY_REPORT Command Receive");

      TempString = "���밡 ID(CMD_YEARLY_REPORT):";
      TempString += WordDataConvert(PCInterface.OrgRx, &cnt);
      MemoMessage->Lines->Add(TempString);


      PCInterface.OrgTx[Count++] = CMD_YEARLY_REPORT;
      TrasferWordDataMake(&Count, PCInterface.OrgTx, (word)112);
        PCInterface.OrgTx[Count++] = 3;
        PCInterface.OrgTx[Count++] = 1;

      for(int i=0;i<12;i++)
      {
        TrasferLongDataMake(&Count, PCInterface.OrgTx, i+1000);
      }

      PCInterface.OrgTxCnt = Count;
      DataSend();
    }
    else
    {
      MemoRxData->Lines->Add("Unknown Command Receive");
    }
  }
  else
  {
    MemoRxData->Lines->Add("CRC üũ ����");
    return;
  }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::BitBtn1Click(TObject *Sender)
{
  Notebook1->ActivePage = "Main";
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::SpeedButton3Click(TObject *Sender)
{
  Notebook1->ActivePage = "Debug";
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::CSpinButton1DownClick(TObject *Sender)
{
  EditDCId->Text = StrToInt(EditDCId->Text) -1;
  EditSettingID->Text = StrToInt(EditDCId->Text);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::CSpinButton1UpClick(TObject *Sender)
{
  EditDCId->Text = StrToInt(EditDCId->Text) + 1;
  EditSettingID->Text = StrToInt(EditDCId->Text);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::ButtonIdStartClick(TObject *Sender)
{
  InfoSave(StrToInt(EditDCId->Text));
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::InfoSave(int UserId)
{
  char TempStr[100] = {0,};
  char TempStr2[100] = {0,};
  sprintf(TempStr,"%d", UserId);
  WritePrivateProfileString("DCID" , "DLCID", TempStr, "Serial.ini");

  sprintf(TempStr,"DC_ID%d", StrToInt(EditDCId->Text));
  WritePrivateProfileString(TempStr , "TargetPower", EditTargetPower->Text.c_str(), "Serial.ini");
  WritePrivateProfileString(TempStr , "LoadNumber", EditLoadNum->Text.c_str(), "Serial.ini");
  unsigned long TempLong;
  TempLong = StrToInt64(EditRCULoad1->Text);
  sprintf(TempStr2,"%d", TempLong);
  WritePrivateProfileString(TempStr , "LoadStatus", TempStr2, "Serial.ini");
  WritePrivateProfileString(TempStr , "CommInterval", EditSettingCommInterval->Text.c_str(), "Serial.ini");
  Timer1->Interval = StrToInt(EditSettingCommInterval->Text)*1000;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::Button4Click(TObject *Sender)
{
  TxCommand = CMD_ACK_CONFIRM;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::Button5Click(TObject *Sender)
{
  Close();  
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::Button6Click(TObject *Sender)
{
  word Count = 0;
  long TempLong;
  PCInterface.OrgTx[Count++] = CMD_BCC_TIME_SYNC;
  TrasferWordDataMake(&Count, PCInterface.OrgTx, StrToInt(EditDCId->Text));

  PCInterface.OrgTxCnt = Count;
  DataSend();    
}
//---------------------------------------------------------------------------

