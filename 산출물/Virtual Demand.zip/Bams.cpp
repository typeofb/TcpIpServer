//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
//#include "Splash.h"
//---------------------------------------------------------------------------
USEFORM("..\..\��뷮 �õ���\Comm Server Total 2\About.cpp", FormAbout);
USEFORM("..\..\��뷮 �õ���\Comm Server Total 2\ControlReport.cpp", FormControlReport);
USEFORM("..\..\��뷮 �õ���\Comm Server Total 2\DBModule.cpp", DataModule1); /* TDataModule: File Type */
USEFORM("..\..\��뷮 �õ���\Comm Server Total 2\DialogBox.cpp", FormDialog);
USEFORM("..\..\��뷮 �õ���\Comm Server Total 2\FormPassword.cpp", PasswordDlg);
USEFORM("..\..\��뷮 �õ���\Comm Server Total 2\RunRatioReport.cpp", FormRunRatio);
USEFORM("..\..\��뷮 �õ���\Comm Server Total 2\UnitGroup1.cpp", FormUserGroup1);
USEFORM("..\..\��뷮 �õ���\Comm Server Total 2\UserInfoDB.cpp", FormUserInfo);
USEFORM("..\..\��뷮 �õ���\Comm Server Total 2\UserInfoReport.cpp", FormUserReport);
USEFORM("..\..\��뷮 �õ���\Comm Server Total 2\UserLoad.cpp", FormUserData);
USEFORM("..\..\��뷮 �õ���\Comm Server Total 2\Main.cpp", FormMain);
USEFORM("..\..\��뷮 �õ���\Comm Server Total 2\IdPasswdForm.cpp", FormIdPasswd);
USEFORM("..\..\��뷮 �õ���\Comm Server Total 2\MainTitle.cpp", FormMainTitle);
USEFORM("..\..\��뷮 �õ���\Comm Server Total 2\ControlView.cpp", FormControlView);
USEFORM("..\..\��뷮 �õ���\Comm Server Total 2\CommForm.cpp", FormCommunication);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
  try
  {
     Application->Initialize();
//     Application->CreateForm(__classid(TDataModule1), &DataModule1);
     Application->CreateForm(__classid(TDataModule1), &DataModule1);
         Application->CreateForm(__classid(TFormMain), &FormMain);
         Application->CreateForm(__classid(TFormRunRatio), &FormRunRatio);
         Application->CreateForm(__classid(TFormMainTitle), &FormMainTitle);
         Application->CreateForm(__classid(TFormControlView), &FormControlView);
         Application->CreateForm(__classid(TFormCommunication), &FormCommunication);
         Application->Run();
  }
  catch (Exception &exception)
  {
     Application->ShowException(&exception);
  }
  catch (...)
  {
     try
     {
       throw Exception("");
     }
     catch (Exception &exception)
     {
       Application->ShowException(&exception);
     }
  }
  return 0;
}
//---------------------------------------------------------------------------
